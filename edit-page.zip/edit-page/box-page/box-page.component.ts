import {
    Component,
    OnInit,
    Injector,
    ElementRef,
    AfterViewInit,
    Renderer2,
    OnDestroy,
    ViewChild,
    Input,
    OnChanges,
    Inject
} from '@angular/core';

import { NzMessageService } from 'ng-zorro-antd/message';
import { NzModalService, NzModalRef } from 'ng-zorro-antd/modal';

// import { PyCoreComponent, Dynamic } from 'pengesoft-ng-lib';

import { ReportCanvasServiceSvr } from '../../../services/r-report-canvas.service';
import { ReportCanvas } from '../../../domains/reportcanvas.domain';
import { IBoxData } from '@views/edit-page/interface/box';

import { BoxShowComponent } from '../box-show/box-show.component';
import { ZLoadService } from '../../../services/z-load.service';
import {DOCUMENT} from '@angular/common';
// extends PyCoreComponent
// @Dynamic()

@Component({
    selector: 'app-box-page',
    templateUrl: './box-page.component.html',
    styleUrls: ['./box-page.component.less']
})
export class BoxPageComponent implements OnInit, AfterViewInit, OnChanges {

    @ViewChild('boxsView') boxsView: BoxShowComponent;

    @Input() repId: string;
    @Input() miniShow: Boolean;
    reportData: ReportCanvas;
    // reportBack: ReportCanvas;
    miniboxAni: Boolean = false; // 盒子动画
    miniboxAniTimer: any;  // 盒子动画timer

    oldW: number;
    oldH: number;

    oldBoxW: number;
    oldBoxH: number;
    userPro: Array<IBoxData> = [];

    timer: any;
    userInfoData: any;

    windowResizeLisnter: () => void;
    openMenu: () => void;
    menuELe: Element;
    loadStu = false;
    constructor(private injector: Injector, private render: Renderer2,
        private reportSvr: ReportCanvasServiceSvr,
        private modal: NzModalService,
        private message: NzMessageService,
        private zloadSrv: ZLoadService,
        @Inject(DOCUMENT) private doc: Document
    ) {
        // super(injector)
    }

    ngOnInit(): void {

    }

    ngOnChanges(changes) {
        if (changes.repId) {
            clearTimeout(this.timer);
            this.timer = setTimeout(() => {
                this.getBoxList();
            }, 200);
        }

    }

    setMainData(data) {
        return JSON.stringify(data || [])
    }

    ngAfterViewInit() {
        setTimeout(() => {
            if (!this.miniShow) {
                this.getBoxList();
            }
        }, 0);
        setTimeout(() => {
            this.menuELe = this.doc.querySelector('.header-left>.header-menu.header-link');
            if (this.menuELe) {
                let openTimer = null;
                this.openMenu = this.render.listen(this.menuELe, 'click', event => {
                    clearTimeout(openTimer);
                    openTimer = setTimeout(() => {
                        this.boxsView?.resizeBox();
                    }, 300);
                })
            }
        }, 300);
    }


    ngOnDestroy(): void {
        if (this.openMenu) {
            this.openMenu();
        }
    }

    async getBoxList() {
        const loadId = this.zloadSrv.open({ele: 'app-box-page'});
        let res;
        try {
            if (this.miniShow) {
                if (this.repId) {
                    res = await this.reportSvr.getCustomPageDetail(this.repId)
                }
            } else {
                res = await this.reportSvr.ReportCanvasSave( 5
                    , null)
            }
        } catch (error) {

        }

        this.zloadSrv.close(loadId);
        this.loadStu = true;
        this.dealViewData(res);
    }

    getUserInfo(): Promise<any> {
        return Promise.resolve({
            then: (rsv) => {
                let data = null;
                // if (this.loginAuthor.roleInfo) {
                //     data = this.loginAuthor;
                //     rsv(data);
                // } else {
                //     // this.loginAuthor.setRole$.subscribe(() => {
                //     //     data = this.loginAuthor;
                //     //     rsv(data);
                //     // })
                // }
            }
        })


    }
    async useDefaultView() {
        if (!this.miniShow) {
            const res = await this.getUserInfo();
            let ressAuth = this.dealDescription(res.roleInfo.Description);
            if (ressAuth.defView) {
                this.modal.create({
            nzCentered: true,
                    nzTitle: '设置',
                    nzContent: '检测当前角色已配置默认首页，是否使用？',
                    nzOnOk: async () => {
                        // return this.reportSvr.getCustomPageDetail(this.loginAuthor.token, ressAuth.defView, { ele: 'app-box-page', text: '加载中' }).then(res => {
                        //     if (res) {
                        //         this.dealViewData(res);
                        //         this.reportSvr.ReportCanvasSave(this.loginAuthor.token, 1, res).then(res => {
                        //             this.message.success('操作成功');
                        //         });
                        //     } else {
                        //         this.message.error('拉取失败，请稍后再试');
                        //     }
                        // }).catch(err => {
                        //     this.message.error(err?.Msg ?? '拉取失败，请稍后再试');
                        // })
                    },
                    nzCloseOnNavigation: true,
                    nzOnCancel: () => { }
                })
            }
        }
    }

    dealDescription(str: string): { [prop: string]: any } {
        let a = str.split(/;|,/);
        if (Array.isArray(a)) {
            return (Object as any).fromEntries(a.map(item => {
                let arr = item.split(':');
                return [arr[0].trim(), arr[1].trim()]
            }))
        }
        return {}
    }

    dealViewData(res) {
        if (res?.CanvasBoxs._Items.length > 0) {
            this.reportData = res;
            let { boxArr, width, height } = this.reportSvr.dataSToC(res);
            this.userPro = boxArr;
            this.oldW = 0;
            this.oldH = 0;
            setTimeout(() => {
                this.oldW = width;
                this.oldH = height;
                setTimeout(() => {
                    this.boxsView?.resizeBox()
                }, 0);
            }, 0);
        } else if (!res?.PersonsId) {
            // this.useDefaultView()
        }
    }
}
