import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { BoxShowComponent } from './box-show.component';

describe('BoxShowComponent', () => {
  let component: BoxShowComponent;
  let fixture: ComponentFixture<BoxShowComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ BoxShowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BoxShowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
