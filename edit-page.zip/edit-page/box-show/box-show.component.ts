import {
    Component,
    OnInit,
    OnDestroy,
    ElementRef,
    AfterViewInit,
    Input,
    OnChanges,
    Renderer2,
    Output,
    EventEmitter
} from '@angular/core';

import { MiniBoxComponent } from '../mini-box/mini-box.component';
import { ToolClass } from '../../../tools';

/** interface */
import {
    ISizeBox,
    IAlignLocation,
    IBlockInter,
    IBoxData,
    IBlockData
} from '../interface/box';

@Component({
    selector: 'app-box-show',
    templateUrl: './box-show.component.html',
    styleUrls: ['./box-show.component.less'],
    exportAs: 'appBoxShow',
    // encapsulation: ViewEncapsulation.None
})
export class BoxShowComponent implements OnInit, OnDestroy, AfterViewInit, OnChanges {
    //
    // boxResizeObserver: { ob: MutationObserver; timer: any } = { ob: null, timer: null };
    // 对齐样式
    xStand: IAlignLocation = { top: "0", display: 'none' };
    yStand: IAlignLocation = { left: "0", display: 'none' };
    private leftChange: number | "no" = "no";
    private topChange: number | "no" = "no";

    // 间距控制
    blockInterArr: Array<IBlockInter> = [];

    // 盒子动画控制
    private miniboxAniTimer: any;

    // 画布样式
    oldBoxW: number;
    oldBoxH: number;
    // boxW: number;
    // boxH: number;
    @Input() boxW: number;
    @Input() boxH: number;
    // @Output() boxWChange = new EventEmitter<number>();
    // @Output() boxHChange = new EventEmitter<number>();
    // 盒子
    @Input() userPro: Array<IBoxData> = [];
    activeProId: string;

    // 编辑控制
    @Input() editeStu: Boolean;
    // 允许对齐
    @Input() disableAlign: Boolean | string = true;

    @Input() alignDis: number = 4;

    windowResizeLisnter: () => void;

    private listOfMiniBoxCompnet: MiniBoxComponent[] = [];

    constructor(private hoseView: ElementRef, private render: Renderer2) {
    }

    get hostSize(): ISizeBox {
        let ele = this.hoseView.nativeElement as HTMLElement;
        return { w: ele?.offsetWidth, h: ele?.offsetHeight }
    }

    ngOnInit(): void {
        this.windowResizeLisnter = this.render.listen('window', 'resize', () => {
            this.resizeBox();
        });
    }

    ngAfterViewInit(): void {
        // this.boxResizeObserver.ob = new MutationObserver((evtArr: Array<MutationRecord>) => {
        //     clearTimeout(this.boxResizeObserver.timer);
        //     this.boxResizeObserver.timer = setTimeout(() => {
        //         this.resizeBox();
        //     }, 200);
        // });
        // this.boxResizeObserver.ob.observe(this.hoseView.nativeElement, {
        //     attributes: true
        // })
    }

    ngOnChanges(change): void {
        // console.log(change, 'change-------');
        // if (change.userPro) {
        //     console.log(change, 'change.userPro', 'resizeBox');
        //     this.resizeBox()
        // }
    }

    ngOnDestroy(): void {
        // if (this.boxResizeObserver) {
        //     this.boxResizeObserver.ob.disconnect()
        // }
        this.windowResizeLisnter();
    }

    addMiniBox(value: MiniBoxComponent) {
        value.parentH = this.hostSize.h;
        value.parentW = this.hostSize.w;
        if (this.editeStu !== undefined) {
            value.editStu = this.editeStu;
        }
        this.listOfMiniBoxCompnet.push(value);
    }

    removeMiniBox(value: MiniBoxComponent) {
        this.listOfMiniBoxCompnet.splice(this.listOfMiniBoxCompnet.indexOf(value), 1);
    }

    // 适应页面
    resizeBox(reload = false) {
        clearTimeout(this.miniboxAniTimer);
        if (this.hostSize.w === 0 || this.hostSize.h === 0) return;
        this.listOfMiniBoxCompnet.forEach(it => it.aniStu = true);
        this.oldBoxW = this.boxW;
        this.oldBoxH = this.boxH;
        this.boxW = this.hostSize.w;
        this.boxH = this.hostSize.h;
        if (this.oldBoxW && this.oldBoxW !== this.boxW || this.oldBoxH && this.oldBoxH !== this.boxH) {
            let ratioW = this.oldBoxW / this.boxW;
            let ratioH = this.oldBoxH / this.boxH;
            this.userPro.forEach(item => {
                if (ratioW !== 1) {
                    item.w = ToolClass.numToFixed(item.w / ratioW);
                    item.l = ToolClass.numToFixed(item.l / ratioW);
                }
                if (ratioH !== 1) {
                    item.h = ToolClass.numToFixed(item.h / ratioH);
                    item.t = ToolClass.numToFixed(item.t / ratioH);
                }
            })
        }
    }

    // 拖动进行  对齐
    resize(size: ISizeBox, moduleId: string) {
        if (this.disableAlign) {
            return
        }
        this.activeProId = moduleId;
        this.pagePost(size);
        this.blockPost(size, moduleId)
    }

    pagePost(newRect: ISizeBox) {
        let disW = newRect.w / 2 + newRect.l;
        let disH = newRect.h / 2 + newRect.t;
        let centerW = this.boxW / 2;
        let centerH = this.boxH / 2;
        if (
            Math.abs(disW - centerW) < this.alignDis &&
            Math.abs(disW - centerW) != 0
        ) {
            this.leftChange = centerW - newRect.w / 2;
            this.yStand.left = "50%";
            this.yStand.display = "block";
        } else if (
            Math.abs(newRect.l - centerW) < this.alignDis &&
            Math.abs(newRect.l - centerW) != 0
        ) {
            this.leftChange = centerW;
            this.yStand.left = "50%";
            this.yStand.display = "block";
        } else if (
            Math.abs(newRect.l + newRect.w - centerW) < this.alignDis &&
            Math.abs(newRect.l + newRect.w - centerW) != 0
        ) {
            this.leftChange = centerW - newRect.w;
            this.yStand.left = "50%";
            this.yStand.display = "block";
        } else {
            this.leftChange = "no";
            this.yStand.display = "none";
        }
        if (
            Math.abs(disH - centerH) < this.alignDis &&
            Math.abs(disH - centerH) != 0
        ) {
            this.xStand.top = "50%";
            this.topChange = centerH - newRect.h / 2;
            this.xStand.display = "block";
        } else if (
            Math.abs(newRect.t - centerH) < this.alignDis &&
            Math.abs(newRect.t - centerH) != 0
        ) {
            this.xStand.top = "50%";
            this.topChange = centerH;
            this.xStand.display = "block";
        } else if (
            Math.abs(newRect.t + newRect.h - centerH) < this.alignDis &&
            Math.abs(newRect.t + newRect.h - centerH) != 0
        ) {
            this.xStand.top = "50%";
            this.topChange = centerH - newRect.h;
            this.xStand.display = "block";
        } else {
            this.xStand.display = "none";
            this.topChange = "no";
        }
    }

    blockPost(newRect: ISizeBox, moduleId: string) {
        if (this.userPro.length < 1) return;
        let resTopArr = [];
        let resLeftArr = [];
        let resBotmArr = [];
        let resRightArr = [];
        let resLevArr = [];
        let resVerArr = [];
        let restBArr = [];
        let resbTArr = [];
        let resrLArr = [];
        let reslRArr = [];
        this.userPro.filter(i => i.moduleId != moduleId).forEach((it: IBoxData) => {
            resTopArr.push({
                dis: Math.abs(it.t - newRect.t),
                obj: it,
            });
            resLeftArr.push({
                dis: Math.abs(it.l - newRect.l),
                obj: it,
            });
            resRightArr.push({
                dis: Math.abs(
                    it.l + it.w - newRect.l - newRect.w
                ),
                obj: it,
            });
            resBotmArr.push({
                dis: Math.abs(
                    it.t + it.h - newRect.t - newRect.h
                ),
                obj: it,
            });
            resLevArr.push({
                dis: Math.abs(
                    it.l +
                    it.w / 2 -
                    newRect.l -
                    newRect.w / 2
                ),
                obj: it,
            });
            resVerArr.push({
                dis: Math.abs(
                    it.t +
                    it.h / 2 -
                    newRect.t -
                    newRect.h / 2
                ),
                obj: it,
            });
            restBArr.push({
                dis: Math.abs(it.t + it.h - newRect.t),
                obj: it,
            });
            resbTArr.push({
                dis: Math.abs(it.t - newRect.t - newRect.h),
                obj: it,
            });
            resrLArr.push({
                dis: Math.abs(it.l - newRect.l - newRect.w),
                obj: it,
            });
            reslRArr.push({
                dis: Math.abs(it.l + it.w - newRect.l),
                obj: it,
            });
        });
        // 边对齐
        // left right
        if (this.leftChange == "no") {
            let leftObjEle = this.findMin(resLeftArr);
            let leftObjCenEle = this.findMin(resLevArr); //水平
            let rightObjEle = this.findMin(resRightArr);
            let rLEle = this.findMin(resrLArr);
            let lREle = this.findMin(reslRArr);

            let leftCenDis =
                leftObjCenEle &&
                Math.abs(
                    newRect.l +
                    newRect.w / 2 -
                    leftObjCenEle.l -
                    leftObjCenEle.w / 2
                );
            let leftDis =
                leftObjEle && Math.abs(leftObjEle.l - newRect.l);
            let rightDis =
                rightObjEle &&
                Math.abs(
                    rightObjEle.l +
                    rightObjEle.w -
                    newRect.l -
                    newRect.w
                );
            let rLEleDis =
                rLEle &&
                Math.abs(rLEle.l - newRect.l - newRect.w);
            let lREleDis =
                lREle && Math.abs(lREle.l + lREle.w - newRect.l);
            if (leftObjCenEle && leftCenDis < this.alignDis && leftCenDis != 0) {
                this.yStand.left =
                    leftObjCenEle.l + leftObjCenEle.w / 2 + "px";
                this.leftChange =
                    leftObjCenEle.l +
                    leftObjCenEle.w / 2 -
                    newRect.w / 2;
                this.yStand.display = "block";
            } else if (leftObjEle && leftDis < this.alignDis && leftDis != 0) {
                this.leftChange = leftObjEle.l;
                this.yStand.left = this.leftChange + "px";
                this.yStand.display = "block";
            } else if (rLEle && rLEleDis < this.alignDis && rLEleDis != 0) {
                this.leftChange = rLEle.l - newRect.w;
                this.yStand.left = rLEle.l + "px";
                this.yStand.display = "block";
            } else if (lREle && lREleDis < this.alignDis && lREleDis != 0) {
                this.leftChange = lREle.l + lREle.w;
                this.yStand.left = this.leftChange + "px";
                this.yStand.display = "block";
            } else if (rightObjEle && rightDis < this.alignDis && rightDis != 0) {
                this.leftChange =
                    rightObjEle.l + rightObjEle.w - newRect.w;
                this.yStand.left =
                    rightObjEle.l + rightObjEle.w + "px";
                this.yStand.display = "block";
            } else {
                this.leftChange = "no";
                this.yStand.display = "none";
            }
        }
        // t bottom
        if (this.topChange == "no") {
            let topObjEle = this.findMin(resTopArr);
            let topObjCenEle = this.findMin(resVerArr); //垂直
            let bottomObjCenEle = this.findMin(resBotmArr);
            let tbEle = this.findMin(restBArr);
            let bTEle = this.findMin(resbTArr);
            let topCenDis =
                topObjCenEle &&
                Math.abs(
                    newRect.t +
                    newRect.h / 2 -
                    topObjCenEle.t -
                    topObjCenEle.h / 2
                );
            let topDis = topObjEle && Math.abs(topObjEle.t - newRect.t);
            let bottomDis =
                bottomObjCenEle &&
                Math.abs(
                    bottomObjCenEle.t +
                    bottomObjCenEle.h -
                    newRect.t -
                    newRect.h
                );
            let tbEleDis =
                tbEle && Math.abs(tbEle.t + tbEle.h - newRect.t);
            let bTEleDis =
                bTEle && Math.abs(bTEle.t - newRect.t - newRect.h);
            if (topObjCenEle && topCenDis < this.alignDis && topCenDis != 0) {
                this.xStand.top =
                    topObjCenEle.t + topObjCenEle.h / 2 + "px";
                this.topChange =
                    topObjCenEle.t +
                    topObjCenEle.h / 2 -
                    newRect.h / 2;
                this.xStand.display = "block";
            } else if (tbEle && tbEleDis < this.alignDis && tbEleDis != 0) {
                this.topChange = tbEle.t + tbEle.h;
                this.xStand.top = this.topChange + "px";
                this.xStand.display = "block";
            } else if (topObjEle && topDis < this.alignDis && topDis != 0) {
                this.topChange = topObjEle.t;
                this.xStand.top = this.topChange + "px";
                this.xStand.display = "block";
            } else if (bTEle && bTEleDis < this.alignDis && bTEleDis != 0) {
                this.topChange = bTEle.t - newRect.h;
                this.xStand.top = bTEle.t + "px";
                this.xStand.display = "block";
            } else if (
                bottomObjCenEle &&
                bottomDis < this.alignDis &&
                bottomDis != 0
            ) {
                this.topChange =
                    bottomObjCenEle.t +
                    bottomObjCenEle.h -
                    newRect.h;
                this.xStand.top =
                    bottomObjCenEle.t + bottomObjCenEle.h + "px";
                this.xStand.display = "block";
            } else {
                this.topChange = "no";
                this.xStand.display = "none";
            }
        }
    }

    findMin(arr: Array<{ dis: number; obj: IBoxData }>): IBoxData {
        arr.sort((a, b) => a.dis - b.dis);
        return (arr[0] && arr[0].obj) || null;
    }

    // 拖动结束值
    resizeStop(newRect: ISizeBox, moduleId: string): void {
        if (this.disableAlign) {
            return
        }
        let itemObj = this.userPro.find(it => it.moduleId == moduleId);
        itemObj.w = newRect.w;
        itemObj.h = newRect.h;
        itemObj.t = newRect.t;
        itemObj.l = newRect.l;
        if (this.topChange != "no") {
            setTimeout(() => {
                itemObj.t = this.topChange as number;
                this.topChange = "no";
            }, 0);
        }
        if (this.leftChange != "no") {
            setTimeout(() => {
                itemObj.l = this.leftChange as number;
                this.leftChange = "no";
            }, 0);
        }
        this.yStand.display = "none";
        this.xStand.display = "none";
    }

    // 快间距定位计算
    blockInterval(currInterObj: IBoxData): { blockInterValue: IBlockData[], blockInterArr: Array<IBlockInter> } {
        let blockInterValue = [
            {
                type: "top",
                label: "上",
                value: 0,
                oldValue: 0,
            },
            {
                type: "bottom",
                label: "下",
                value: 0,
                oldValue: 0,
            },
            {
                type: "left",
                label: "左",
                value: 0,
                oldValue: 0,
            },
            {
                type: "right",
                label: "右",
                value: 0,
                oldValue: 0,
            }
        ];
        let topV = currInterObj.t;
        let leftV = currInterObj.l;
        let bottomV = currInterObj.t + currInterObj.h;
        let rightV = currInterObj.l + currInterObj.w;
        let resTopArr = [];
        let resbottomArr = [];
        let resLeftArr = [];
        let resRightArr = [];
        for (let item of this.userPro) {
            if (item.moduleId != currInterObj.moduleId) {
                let bottomI = item.t + item.h;
                let rightI = item.l + item.w;
                let isbottom = item.t > bottomV;
                let isTop = bottomI < topV;
                if (
                    !(item.l > rightV || rightI < leftV) &&
                    (isbottom || isTop)
                ) {
                    let objA: IBlockInter = {
                        obj: item,
                        l: 0,
                        t: ToolClass.numToFixed(isbottom ? bottomV : bottomI),
                        h: ToolClass.numToFixed(isbottom
                            ? item.t - bottomV
                            : topV - bottomI),
                        w: 0,
                        type: isbottom ? "bottom" : "top",
                    };

                    if (item.l >= leftV && rightI <= rightV) {
                        objA.l = ToolClass.numToFixed(item.l + item.w / 2);
                    } else if (item.l < leftV && rightI <= rightV) {
                        objA.l = ToolClass.numToFixed((rightI - leftV) / 2 + leftV);
                    } else if (rightI > rightV && item.l >= leftV) {
                        objA.l = ToolClass.numToFixed((rightV - item.l) / 2 + item.l);
                    } else {
                        objA.l = ToolClass.numToFixed(leftV + currInterObj.w / 2);
                    }
                    if (isTop) {
                        resTopArr.push(objA);
                    } else {
                        resbottomArr.push(objA);
                    }
                    continue;
                }
                let isRight = item.l > rightV;
                let isLeft = rightI < leftV;
                if (
                    !(item.t > bottomV || bottomI < topV) &&
                    (isRight || isLeft)
                ) {
                    let objA: IBlockInter = {
                        obj: item,
                        l: ToolClass.numToFixed(isRight ? rightV : rightI),
                        t: 0,
                        h: 0,
                        w: ToolClass.numToFixed(isRight
                            ? item.l - rightV
                            : leftV - rightI),
                        isLeft,
                        type: isRight ? "right" : "left",
                    };

                    if (item.t >= topV && bottomI <= bottomV) {
                        objA.t = ToolClass.numToFixed(item.t + item.h / 2);
                    } else if (item.t < topV && bottomI <= bottomV) {
                        objA.t = ToolClass.numToFixed((bottomI - topV) / 2 + topV);
                    } else if (item.t >= topV && bottomI > bottomV) {
                        objA.t = ToolClass.numToFixed((bottomV - item.t) / 2 + item.t);
                    } else {
                        objA.t = ToolClass.numToFixed(topV + currInterObj.h / 2);
                    }
                    if (isLeft) {
                        resLeftArr.push(objA);
                    } else {
                        resRightArr.push(objA);
                    }
                    continue;
                }
            }
        }

        resLeftArr.sort((a, b) => a.w - b.w);
        resRightArr.sort((a, b) => a.w - b.w);
        resTopArr.sort((a, b) => a.h - b.h);
        resbottomArr.sort((a, b) => a.h - b.h);

        let topObj: IBlockInter = resTopArr[0];
        let bottomObj: IBlockInter = resbottomArr[0];
        let rightObj: IBlockInter = resRightArr[0];
        let leftObj: IBlockInter = resLeftArr[0];
        if (!topObj) {
            topObj = {
                w: 0,
                t: 0,
                l: ToolClass.numToFixed(currInterObj.w / 2 + leftV),
                h: ToolClass.numToFixed(topV),
                type: "top",
            };
        }
        if (!bottomObj) {
            bottomObj = {
                w: 0,
                t: ToolClass.numToFixed(topV + currInterObj.h),
                l: ToolClass.numToFixed(currInterObj.w / 2 + leftV),
                h: ToolClass.numToFixed(this.boxH - topV - currInterObj.h),
                type: "bottom",
            };
        }
        if (!rightObj) {
            rightObj = {
                w: ToolClass.numToFixed(this.boxW - leftV - currInterObj.w),
                t: ToolClass.numToFixed(topV + currInterObj.h / 2),
                l: ToolClass.numToFixed(leftV + currInterObj.w),
                h: 0,
                type: "right",
            };
        }
        if (!leftObj) {
            leftObj = {
                w: ToolClass.numToFixed(leftV),
                t: ToolClass.numToFixed(topV + currInterObj.h / 2),
                l: 0,
                h: 0,
                type: "left",
            };
        }
        this.blockInterArr = [];
        blockInterValue[0].value = topObj.h;
        blockInterValue[0].oldValue = topObj.h;

        blockInterValue[1].value = bottomObj.h;
        blockInterValue[1].oldValue = bottomObj.h;

        blockInterValue[2].value = leftObj.w;
        blockInterValue[2].oldValue = leftObj.w;

        blockInterValue[3].value = rightObj.w;
        blockInterValue[3].oldValue = rightObj.w;

        this.blockInterArr.push(topObj);
        this.blockInterArr.push(bottomObj);
        this.blockInterArr.push(leftObj);
        this.blockInterArr.push(rightObj);
        return { blockInterValue, blockInterArr: this.blockInterArr };
    }

    closeBlockInterval() {
        this.blockInterArr = []
    }
}
