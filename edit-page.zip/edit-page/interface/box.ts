import { IPropObj } from '@inter/com-pool';

export interface IBoxData {
    w: number;
    h: number;
    l: number;
    t: number;
    name: string;
    proId: string;
    moduleId: string;
    selector: string;
    title: string;
    show?: Boolean,
    checked?: Boolean,
    propArr?: Array<IPropObj>,
    zIndex?: number,
    __lockBox?: Boolean;
}


export interface IPro {
    name: string;
    proId: string;
    selector: string,
    checked?: Boolean;
    [prop: string]: any
}

export interface IBoxSize {
    boxW: number;
    boxH: number;
}

export interface IAlignLocation { left?: string, top?: string; display?: 'none' | 'block' }

export interface ISizeBox {
    w?: number; h?: number; l?: number; t?: number;
}

export interface IBlockInter { w: number; h: number; l: number; t: number; type: string, obj?: any; isLeft?: Boolean }


export type ResizeAction = 'move' | 'tr' | 'tl' | 'tc' | 'br' | 'bc' | 'bl' | 'lc' | 'rc';

export interface ILocateXY {
    xV: number;
    yV: number;
}

export interface IRightMenu {
    label: string;
    method?: (res?: IRightRes) => void;
    iconCls?: string;
    rightT?: string;
    show?: Boolean;
    menuId?: string;
    clsType?: 'no' | 'all' | 'self',
    children?: IRightMenu[],
    childId?: string
}

export interface IRightRes { evt: MouseEvent; ind: number; item: IRightMenu }

export interface IObj<T> { [prop: string]: T }

export type nameForSelect = 'contentMenu' | 'loadCom' | 'dynamicForm';

export interface IDynamicRes {
    ele?: any;
    destroy: (callback?: Function) => void,
    type: nameForSelect,
    dyId?: string;
    active?: Boolean;
}


export interface IBlockData {
    type: string;
    label: string;
    value: number;
    oldValue: number
}

export interface ICanvasCDeal { boxArr: IBoxData[]; width: number; height: number }


export interface ISizeEle { width?: number; left?: number; top?: number; height?: number; bottom?: number; right?: number }
