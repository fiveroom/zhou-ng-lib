import {AfterViewInit, Component, Inject, Injector, OnDestroy, OnInit, ViewChild} from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { Validators } from '@angular/forms';
import { fromEvent, Observable, Subscription } from 'rxjs';
import { switchMap } from 'rxjs/operators';

import { NzMessageService } from 'ng-zorro-antd/message';
import { NzModalService } from 'ng-zorro-antd/modal';


import { ReportCanvas } from '../../../domains/reportcanvas.domain';
import { IBlockData, IBlockInter, IBoxData, IPro, IRightMenu } from '../interface/box';
import { IPropObj } from '../../../interface/com-pool';
import { ComPoolService } from '../../../services/com-pool.service';
import { ReportCanvasServiceSvr } from '../../../services/r-report-canvas.service';
import { DynamicService } from '../dynamic.service';
import { ZLoadService } from '../../../services/z-load.service';

import { inputClass } from '../../../components/dynamic-form/question-type';

import { BoxShowComponent } from '../box-show/box-show.component';

import { ToolClass } from '../../../tools';
import { DynamicFormService } from '../../../components/dynamic-form/dynamic-form.service';
import {DOCUMENT} from '@angular/common';
import {requiredWithTrim} from '@/tools/validator.tool';
interface IAlignOption {
    label: string;
    value: string;
    checked?: Boolean
}

@Component({
    selector: 'app-box-edit',
    templateUrl: './box-edit.component.html',
    styleUrls: ['./box-edit.component.less']
})
export class BoxEditComponent implements OnInit, AfterViewInit, OnDestroy {

    @ViewChild('boxsView') boxsView: BoxShowComponent;

    searchValue: string = '';
    saveUserPro: Subscription;
    closeRightMenu: Subscription;

    // 用户相关
    proArr: IPro[] = [];
    userPro: IBoxData[] = [];
    proArrAlign: IBoxData[];

    // 右边抽屉
    rDrawerShow: Boolean = true;
    saveUserProDown: Subscription;

    // 盒子相关
    oldW: number;
    oldH: number;

    // 盒子对齐
    alignDig: Boolean = false;
    alignOption: Array<IAlignOption> = [{
        label: '横向',
        value: 'crosswise',
        checked: false
    }, {
        label: '纵向',
        value: 'lengthways',
        checked: false
    }];

    allChecked: Boolean = false;

    // 当前盒子对象
    currInterObj: IBoxData = null;

    // 盒子间距
    intervalDig: Boolean = false;
    blockInterArr: Array<IBlockInter> = [];
    blockInterValue: IBlockData[] = [];

    // 新增模块
    addModuleDig: Boolean = false;

    // 页面保存
    isAdd: Boolean = false;
    saveLoad: Boolean = false;

    reportData: ReportCanvas;
    reportBack: ReportCanvas;

    // 菜单
    boxShowMenu: IRightMenu[];
    miniRightMenu: IRightMenu[];
    currDyId: string;
    _viewId: string;



    constructor(
        private router: Router,
        private message: NzMessageService,
        private reportSvr: ReportCanvasServiceSvr,
        private injector: Injector,
        private dySr: DynamicService,
        private mode: NzModalService,
        private dyFrom: DynamicFormService,
        private zLoad: ZLoadService,
        private route: ActivatedRoute,
        @Inject(DOCUMENT) private doc: Document
    ) {
        // super(injector);
        this.boxShowMenu = [{
            label: '添加模块',
            method: this.addModule.bind(this),
            iconCls: 'iconfont icon-xitongpeizhi',
        }, {
            label: '模块',
            method: this.openModule.bind(this),
            rightT: 'ctrl + b',
            menuId: 'showModule',
            show: true
        }, {
            label: '等间距',
            method: this.alignPro.bind(this),
            iconCls: 'iconfont icon-duiqi'
        }, {
            label: '保存',
            method: this.savePage.bind(this),
            rightT: 'ctrl + s',
        }];
        this.miniRightMenu = [{
            label: '间距调整',
            method: this.openInterVal.bind(this),
            iconCls: 'iconfont icon-jianzhujianju'
        }, {
            label: `尺寸、类型`,
            method: this.editSize.bind(this),
            rightT: 'ctrl + b',
        }, {
            label: '源数据',
            method: this.editeData.bind(this),
            iconCls: 'iconfont icon-icon_huabanfuben'
        }, {
            label: '层级',
            clsType: 'no',
            iconCls: 'iconfont icon-arrow-right-bold',
            children: [
                {
                    label: '顶部',
                    method: this.toTopZindex.bind(this),
                    iconCls: 'iconfont icon-dingbu',
                }, {
                    label: '向上',
                    method: this.upZindex.bind(this),
                    iconCls: 'iconfont icon-xiangshang',
                    clsType: 'no',
                }, {
                    label: '向下',
                    method: this.downZindex.bind(this),
                    iconCls: 'iconfont icon-xiangxia',
                    clsType: 'no',
                }, {
                    label: '底部',
                    method: this.toBottomZindex.bind(this),
                    iconCls: 'iconfont icon-dibu',
                },
            ]
        }, {
            label: '删除',
            method: this.deleteUserPro.bind(this),
            iconCls: 'iconfont icon-shanchu'
        }, {
            label: '锁定',
            menuId: 'lockBox',
            method: () => {
                this.currInterObj.__lockBox = !this.currInterObj.__lockBox;
            },
            iconCls: 'iconfont icon-suoding',
            show: true
        }];
        this.proArr = ComPoolService.getByType('minibox').map(it => ({
            proId: it.comId,
            name: it.name,
            selector: it.selector,
            propArr: it.propArr,
            checked: false,
            key: it.name,
            value: it.comId
        }));
    }

    get okDisabled(): Boolean {
        return this.alignOption.every(it => !it.checked) || this.proArrAlign.filter(it => it.checked).length <= 2;
    }

    get allCheckPro(): Boolean {
        return this.proArr.length !== 0 && this.proArr.every(i => i.checked);
    }

    // 选择所有
    set allCheckPro(val) {
        this.proArr.forEach(i => i.checked = val);
        this.proArr.forEach(i => this.checkPro(val, i));
    }

    get searchUserPro(): Array<IBoxData> {
        return this.userPro.filter(it => it.title.includes(this.searchValue));
    }

    ngOnInit(): void {
        this.message.info('使用右键菜单进行模块添加等操作', {
            nzDuration: 2000,
            nzAnimate: true
        });
        this.saveUserProDown = fromEvent(this.doc, 'keydown').subscribe((evt: KeyboardEvent) => {
            if (evt.ctrlKey) {
                if (evt.key == 's') {
                    evt.preventDefault();
                } else if (evt.key == 'b') {
                    evt.preventDefault();
                }
            }
        });
        this.saveUserPro = fromEvent(this.doc, 'keyup').subscribe((evt: KeyboardEvent) => {
            if (evt.ctrlKey) {
                if (evt.key == 's') {
                    evt.preventDefault();
                    if (!this.saveLoad) {
                        this.savePage();
                    }

                } else if (evt.key == 'b') {
                    evt.preventDefault();
                    this.openModule();
                }
            }
        });

        this.closeRightMenu = fromEvent(this.doc, 'click').subscribe((evt) => {
           this.dySr.closeByType('contentMenu')
        });
    }

    ngAfterViewInit() {
        this.getBoxList().then();

    }

    ngOnDestroy(): void {
        if (this.saveUserPro) {
            this.saveUserPro.unsubscribe();
        }
        if (this.saveUserProDown) {
            this.saveUserProDown.unsubscribe();
        }
        this.closeRightMenu?.unsubscribe();

        this.dySr.closeByType('contentMenu');
        this.zLoad.closeAll()
    }

    setMainData(data: Array<IPropObj>) {
        return JSON.stringify(data || []);
    }

    // 层级编辑
    toTopZindex() {
        this.currInterObj.zIndex = Math.max.apply(null, this.userPro.map(item => item.zIndex)) + 1;
    }

    toBottomZindex() {
        this.currInterObj.zIndex = 0;
    }

    upZindex() {
        ++this.currInterObj.zIndex;
    }

    downZindex() {
        this.currInterObj.zIndex = --this.currInterObj.zIndex == -1 ? 0 : this.currInterObj.zIndex;
    }

    // 获取列表
    async getBoxList() {
        let res;
        if(!this._viewId){
            this._viewId  = await this.getId();
        }
        if(this._viewId){
            res = await this.reportSvr.getCustomPageDetail( this._viewId, { text: '加载中...' });
            this.isAdd = true;
        } else {
            res = await this.reportSvr.ReportCanvasSave( 5, null, { text: '加载中...' }
            )
            this.isAdd = !!res.PersonsId;
        }
        if(!res.CanvasBoxs){
            res.CanvasBoxs = {
                _Items: [],
                MaxId: 0
            }
        }
        this.reportData = res;
        this.reportBack = JSON.parse(JSON.stringify(res));
        let { boxArr, width, height } = this.reportSvr.dataSToC(res);
        this.userPro = boxArr;
        this.oldW = width;
        this.oldH = height;
        setTimeout(() => {
            this.boxsView.resizeBox(true);
        }, 0)
    }

    getId(): Promise<string>{
        return new Promise((rsv)=>{
            this.route.paramMap.subscribe(res=>{
                rsv(res.get('id'))
            })
        })
    }

    checkPro(checked: Boolean, item: IPro) {
        item.checked = checked;
    }

    // 对齐
    alignPro(): void {
        this.alignDig = true;
        this.proArrAlign = null;
        setTimeout(() => {
            this.userPro.forEach(it => it.checked = false);
            this.proArrAlign = this.userPro;
        }, 0);
    }

    // 确认回调
    alignDigOk() {
        let checkOption = this.proArrAlign.filter(it => it.checked);
        let num = checkOption.length - 1;
        this.alignOption.forEach(it => {
            if (it.checked) {
                let direct = 't';
                let size = 'h';
                if (it.value == 'crosswise') {
                    direct = 'l';
                    size = 'w';
                }
                checkOption.sort((a, b) => a[direct] - b[direct]);
                let interval =
                    (checkOption[num][direct] +
                        checkOption[num][size] -
                        (checkOption as any[]).reduce((a: any, b: any, ind): number => {
                            if (ind == 1) {
                                return a[size] + b[size];
                            }
                            return a + b[size];
                        }) -
                        checkOption[0][direct]) /
                    num;
                checkOption.reduce((b, n, ind) => {
                    if (ind != num) {
                        n[direct] = b[direct] + b[size] + interval;
                    }
                    return n;
                });
            }
        });
        this.alignDig = false;
    }

    // 取消回调
    alignDigCancel() {
        this.alignDig = false;
    }

    // 关闭后回调
    alignDigAfterCls() {
        this.alignOption.forEach(it => it.checked = false);
        this.proArrAlign.forEach(it => it.checked = false);
        this.allChecked = false;
    }

    // 全选
    checkAllPro(evt) {
        this.proArrAlign.forEach(it => it.checked = evt);
    }

    // 每个选项选中
    onItemChecked() {
        this.allChecked = this.proArrAlign.every(it => it.checked);
    }

    // 间距调整
    openInterVal() {
        let { blockInterValue, blockInterArr } = this.boxsView.blockInterval(this.currInterObj);
        this.blockInterValue = blockInterValue;
        this.blockInterArr = blockInterArr;
        this.intervalDig = true;
    }

    intervalDigOk(): void {
        this.currInterObj.t = parseFloat(this.blockInterValue[0].value + '') + this.blockInterArr[0].t;
        this.currInterObj.l = parseFloat(this.blockInterValue[2].value + '') + this.blockInterArr[2].l;
        this.intervalDig = false;
    }

    intervalDigCancel() {
        this.blockInterArr = [];
        this.boxsView.closeBlockInterval();
    }

    changeInter(val: number, item: any) {
        if (!isNaN(val) && val >= 0) {
            let obj = this.findInterObj(item.type);
            let diff = item.oldValue - val;
            item.oldValue = val;
            obj.oldValue = obj.value;
            obj.value = parseFloat(obj.value + '') + diff;
        }
    }

    findInterObj(type: string): any {
        switch (type) {
            case 'top':
                return this.blockInterValue.find(
                    (it) => it.type == 'bottom'
                );
            case 'bottom':
                return this.blockInterValue.find((it) => it.type == 'top');
            case 'left':
                return this.blockInterValue.find(
                    (it) => it.type == 'right'
                );
            case 'right':
                return this.blockInterValue.find((it) => it.type == 'left');
        }
    }

    // 尺寸大小
    editSize() {
        this.dyFrom.open({
            questions: [
                new inputClass.textbox({
                    key: 'title',
                    label: '名称',
                    value: this.currInterObj.title,
                    verify: [{
                        rule: requiredWithTrim,
                        info: '请输入',
                        name: 'required'
                    }, {
                        rule: Validators.minLength(2),
                        info: '最少2位',
                        name: 'minLength'
                    }]
                }),
                new inputClass.dropdown({
                    key: 'proId',
                    label: '模块',
                    options: this.proArr,
                    value: this.currInterObj.proId
                }), new inputClass.num({
                    key: 'w',
                    label: '宽度',
                    value: this.currInterObj.w
                }),
                new inputClass.num({
                    key: 'h',
                    label: '高度',
                    value: this.currInterObj.h
                })
            ],
            title: '类型、尺寸',
            ok: (res, close: Function) => {
                this.currInterObj.h = res.h;
                this.currInterObj.w = res.w;
                this.currInterObj.title = res.title;
                if (res.proId != this.currInterObj.proId) {
                    let obj: IPro = this.proArr.find(it => it.proId == res.proId);
                    this.currInterObj.proId = obj.proId;
                    this.currInterObj.selector = obj.selector;
                    this.currInterObj.name = obj.name;
                    this.currInterObj.propArr = ComPoolService.getProp(obj.selector);
                }
                close();
            },
        });
    }

    // 菜单
    contentM(evt: MouseEvent, type?: string, item?: IBoxData) {
        this.dySr.closeAll();
        evt.preventDefault();
        evt.stopPropagation();
        let menuArr: IRightMenu[] = [];
        if (type == 'mini') {
            this.currInterObj = item;
            menuArr = this.miniRightMenu;
            menuArr.find(it => it.label == '源数据').show = this.currInterObj.propArr.length ? true : false;
            menuArr.find(it => it.menuId == 'lockBox').label = this.currInterObj.__lockBox ? '解锁' : '锁定';
        } else {
            this.boxShowMenu.find(it => it.menuId == 'showModule').label = `${this.rDrawerShow ? '折叠' : '展开'}模块`;
            menuArr = this.boxShowMenu;
        }
        this.currDyId = this.dySr.open('contentMenu', {
            menuArr,
            clickLocat: { left: evt.clientX, top: evt.clientY }
        });
    }

    judgeData(): Boolean {
        let res: Boolean = false;
        if (this.isAdd) {
            this.reportSvr.dataCToS({
                width: this.boxsView.hostSize.w,
                height: this.boxsView.hostSize.h,
                boxArr: this.userPro
            }, this.reportData);
            res = ToolClass.compDeepValue(this.reportData, this.reportBack, ['__property', 'MaxID']);
        }
        return res;
    }

    // 保存
    savePage(): void {
        if (!this.judgeData()) {
            this.saveLoad = true;
            this.reportSvr.ReportCanvasSave(this.isAdd ? 4 : 1, this.reportData, { text: '保存中...' }).then(res => {
                if (res) {
                    this.message.success('保存成功');
                }
                this.getBoxList().then();
            }).catch(err => {
                this.message.error(err.Msg || '操作失败，请稍后再试');
            }).finally(() => this.saveLoad = false);
        } else {
            this.message.warning('未做任何修改');
        }
    }

    openModule(): void {
        this.rDrawerShow = !this.rDrawerShow;
        setTimeout(() => {
            this.boxsView.resizeBox()
        }, 200);
    }

    // 数据编辑
    editeData() {
        let propArr = ComPoolService.getProp(this.currInterObj.proId);
        this.dyFrom.open({
            questions: propArr.map(item => {
                return new inputClass[item.dataType]({
                    key: item.key,
                    label: item.label,
                    value: this.currInterObj.propArr.find(i => i.key == item.key)?.value,
                    row: !!item.cfg.row,
                    options: item.cfg.option
                });
            }),
            title: '数据编辑',
            ok: (res, close) => {
                this.currInterObj.propArr.forEach(it => {
                    it.value = res[it.key];
                });
                close();
            }

        });
    }

    addModule() {
        this.addModuleDig = true;
    }

    // 新增模块
    addMoudleItem(item: IPro): void {
        let moduleId = this.dySr.setProId();
        let maxZIndex = Math.max.apply(null, this.userPro.length ? this.userPro.map(i => i.zIndex) : [0]) + 1;
        let obj: IBoxData = {
            w: 260,
            h: 260,
            l: this.boxsView.hostSize.w / 2 - 130,
            t: this.boxsView.hostSize.h / 2 - 130,
            name: item.name,
            proId: item.proId,
            moduleId: moduleId,
            selector: item.selector,
            title: item.name,
            checked: false,
            propArr: Object.assign(item.propArr),
            zIndex: maxZIndex,
            __lockBox: false
        };
        this.userPro = [...this.userPro, obj];
    }

    // 移除模块
    deleteUserPro(evt: any, moduleId: string) {
        this.userPro.splice(this.userPro.findIndex(it => it.moduleId == (moduleId || this.currInterObj.moduleId)), 1);
    }

    changeLink(href: string) {
        this.router.navigateByUrl(href);
    }

    canDeactivate(): Observable<boolean> | Promise<boolean> | boolean {
        if (!this.judgeData()) {
            return new Promise((resolve) => {
                this.mode.confirm({
                    nzTitle: '<i>是否保存</i>',
                    nzOnOk: () => {
                        this.reportSvr.ReportCanvasSave( this.isAdd ? 4 : 1, this.reportData).then(res => {
                            this.message.success('保存成功');
                            resolve(true);
                        }).catch((err) => {
                            this.message.error(err?.Msg || '保存失败');
                            resolve(false);
                        });
                    },
                    nzOnCancel: () => {
                        resolve(true);
                    }
                });
            });
        }
        return true;
    }
}
