import {
    Component,
    OnInit,
    ChangeDetectorRef,
    OnDestroy,
    ViewChild,
    ElementRef,
    EventEmitter,
    Input,
    Output,
    TemplateRef,
    Host,
    Optional,
    AfterViewInit, OnChanges, SimpleChanges, Inject
} from '@angular/core';
import { BoxShowComponent } from '../box-show/box-show.component';
import { ResizeAction, ILocateXY, ISizeBox } from '../interface/box';
import {Subject} from 'rxjs';
import {debounceTime, throttle, throttleTime} from 'rxjs/operators';
import {DOCUMENT} from '@angular/common';
import {animate, style, transition, trigger} from '@angular/animations';

interface IEventM { remove: Function };

@Component({
    selector: 'app-mini-box',
    templateUrl: './mini-box.component.html',
    styleUrls: ['./mini-box.component.less'],
    animations: [
        trigger('showBoxEdit', [
            transition('void => *', [
                style({
                    opacity: '0'
                }),
                animate('.1s', style({opacity: '1'}))
            ])
        ])
    ]
})
export class MiniBoxComponent implements OnInit, OnDestroy, AfterViewInit, OnChanges {

    mouseAction: ResizeAction;  // 行为

    mnMove: IEventM;
    mnDown: IEventM;
    mnUp: IEventM;

    mouseDownStu: Boolean = false;
    mouseDownEle: any;
    parentDis: ILocateXY;
    clickLocat: ILocateXY = { xV: 0, yV: 0 };
    @Input() tipsEdit: TemplateRef<any>;  // 编辑提示
    @Input() editStu: Boolean = false;

    @Input() parentW: number;
    @Input() parentH: number;

    @ViewChild('miniBox') box: ElementRef;
    subject$: Subject<any> = new Subject();
    @Input() moduleId: string;
    @Input() minWidth: number = 50;
    @Input() minHeight: number = 50;
    @Input() maxWidth: number = 400;
    @Input() maxHeight: number = 400;
    @Input() w: number = 200;
    @Input() h: number = 200;
    @Input() l: number = 20;
    @Input() t: number = 20;
    @Input() zIndex: number;
    @Input() miniChecked: Boolean = false;

    @Input() mainEleStr: string;
    @Input() mainData: any;

    @Input() aniStu: Boolean = false; // 动画
    @Input() lock: Boolean = false;
    @Output() resize = new EventEmitter<ISizeBox>();  // 过程中
    @Output() resizeStop = new EventEmitter<ISizeBox>();  // 移动中
    @Output() contentMini = new EventEmitter<MouseEvent>();
    watchProp = ['l', 't', 'w', 'h', 'zIndex']

    constructor(
        private cdr: ChangeDetectorRef, @Inject(DOCUMENT) private doc: Document, @Optional() @Host() private boxShowComponent?: BoxShowComponent,
        ) {
    }

    ngOnChanges(changes: SimpleChanges) {
        if(this.watchProp.some(i => changes[i] && !changes[i].firstChange)){
            this.subject$.next()
        }
    }



    ngOnInit(): void {
        this.minWidth = this.minWidth < 50 ? 50 : this.minWidth;
        this.minHeight = this.minHeight < 50 ? 50 : this.minHeight;
        this.boxShowComponent?.addMiniBox(this);
        this.subject$.subscribe(() => {
            this.setBoxStyle()
        })
    }

    ngAfterViewInit() {
        this.parentDis = this.getPdisBody(this.box.nativeElement);
        if (this.editStu) {
            this.mnUp = this.bindEvent('mouseup', this.miniBoxMUp, this.doc.documentElement);
            this.mnMove = this.bindEvent('mousemove', this.boxMove, this.doc.documentElement);
            this.mnDown = this.bindEvent('mousedown', this.miniBoxMdown, this.doc.documentElement);
        }
        this.subject$.next();
    }

    ngOnDestroy() {
        this.mnMove?.remove()
        this.mnUp?.remove()
        this.mnDown?.remove()
        this.boxShowComponent?.removeMiniBox(this);
        this.subject$.unsubscribe()
    }

    bindEvent(eventName: string, callBack: Function, ele: Element): IEventM {

        let callEvent = (evt) => {
            callBack.call(this, evt);
        };
        ele.addEventListener(eventName, callEvent);
        return {
            remove: () => {
                ele.removeEventListener(eventName, callEvent);
            }
        }
    }

    boxDown(evt: MouseEvent) {
        if (!this.editStu || this.lock) {
            return
        }

        let obj = (<any>evt.target).dataset;
        this.mouseDownStu = true;
        this.mouseAction = obj.movetype;
        if (obj.movetype == 'move') {
            this.clickLocat.xV = evt.offsetX + (<any>evt.target).offsetLeft;
            this.clickLocat.yV = evt.offsetY + (<any>evt.target).offsetTop;
        }
        this.mouseDownEle = evt.target;
        evt.stopPropagation();
    }

    boxMove(evt: MouseEvent) {
        if (!this.editStu || this.lock) {
            return
        }
        if (this.mouseDownStu) {
            evt.preventDefault()
            if (this.mouseAction) {
                let locat: ISizeBox = {};
                let absDisP: ILocateXY = {
                    xV: evt.pageX - this.parentDis.xV,
                    yV: evt.pageY - this.parentDis.yV,
                }
                if (this.mouseAction == 'move') {
                    locat = this.actionMove(absDisP);
                } else {
                    if (this.mouseAction.includes('b'))
                        Object.assign(locat, this.actionB(absDisP))
                    if (this.mouseAction.includes('t'))
                        Object.assign(locat, this.actionT(absDisP))
                    if (this.mouseAction.includes('l'))
                        Object.assign(locat, this.actionL(absDisP))
                    if (this.mouseAction.includes('r'))
                        Object.assign(locat, this.actionR(absDisP))
                }
                this.changeLocat(locat);
                this.subject$.next()
            }
        }
    }

    changeLocat(option: ISizeBox) {
        let obj: ISizeBox = {
            w: this.w = option.w ?? this.w,
            h: this.h = option.h ?? this.h,
            l: this.l = option.l ?? this.l,
            t: this.t = option.t ?? this.t
        }
        this.boxShowComponent?.resize(obj, this.moduleId);
        this.resize.emit(obj)
    }

    miniBoxMdown() {
        if (!this.editStu || this.lock) {
            return
        }
        this.mouseDownStu = false;
    }

    miniBoxMUp() {
        if (!this.editStu || this.lock) {
            return
        }
        // this.compareEle(evt)
        if (this.mouseAction) {
            let obj = {
                w: this.w,
                h: this.h,
                l: this.l,
                t: this.t
            }
            this.boxShowComponent?.resizeStop(obj, this.moduleId);
            this.resizeStop.emit(obj)
            this.mouseAction = null;
        }
    }

    compareEle(evt: MouseEvent): Boolean {
        return (evt as any).path.some(it => it === this.box.nativeElement)
    }

    actionMove(evt: ILocateXY): ISizeBox {
        let needL = evt.xV - this.clickLocat.xV;
        let needT = evt.yV - this.clickLocat.yV;
        if (needL < 0) {
            needL = 0;
        } else if (needL + this.w > this.parentW) {
            needL = this.parentW - this.w
        }
        if (needT < 0) {
            needT = 0;
        } else if (needT + this.h > this.parentH) {
            needT = this.parentH - this.h
        }
        return {
            l: needL,
            t: needT
        }
    }

    getPdisBody(ele: any): ILocateXY {
        let parent = ele.offsetParent;
        let dis = {
            xV: 0,
            yV: 0
        };
        let locatInfo = parent.getBoundingClientRect();
        dis.xV = locatInfo.left + parent.clientLeft;
        dis.yV = locatInfo.top + parent.clientTop;
        return dis
    }

    actionR(evt: ILocateXY): ISizeBox {
        let needW = evt.xV - this.l;
        if (needW + this.l > this.parentW) {
            needW = this.parentW - this.l
        }
        if (needW < this.minWidth) {
            needW = this.minWidth
        }
        return {
            w: needW
        }
    }

    actionL(evt: ILocateXY): ISizeBox {
        let needW = this.w - evt.xV + this.l;
        let needL = evt.xV;
        if (needL < 0) {
            needL = 0;
            needW = this.l + this.w;
        }
        if (needW < this.minWidth) {
            needL = this.l + this.w - this.minWidth;
            needW = this.minWidth;
        }
        return {
            w: needW,
            l: needL,
        }
    }

    actionT(evt: ILocateXY): ISizeBox {
        let needH = this.h - evt.yV + this.t;
        let needT = evt.yV;
        if (needT < 0) {
            needT = 0;
            needH = this.t + this.h;
        }
        if (needH < this.minHeight) {
            needH = this.minHeight;
            needT = this.t + this.h - this.minHeight;
        }
        return {
            h: needH,
            t: needT
        }
    }

    actionB(evt: ILocateXY): ISizeBox {
        let needH = evt.yV - this.t;
        if (needH + this.t > this.parentH) {
            needH = this.parentH - this.t;
        }
        if (needH < this.minHeight) {
            needH = this.minHeight;
        }
        return {
            h: needH
        }
    }

    // 右键菜单
    menuOut(evt: MouseEvent) {
        if (!this.editStu) {
            return
        }
        this.contentMini.emit(evt);
    }


    markForCheck() {
        this.cdr.markForCheck()
    }

    setBoxStyle(){
        (this.box.nativeElement as HTMLElement).style.transform = `translate(${Math.round(this.l)}px, ${Math.round(this.t)}px)`;
        (this.box.nativeElement as HTMLElement).style.width = `${this.w}px`;
        (this.box.nativeElement as HTMLElement).style.height = `${this.h}px`;
        (this.box.nativeElement as HTMLElement).style.zIndex = `${this.zIndex}`;
    }

    animationend($event: AnimationEvent) {
    }

    transitionend() {
        this.aniStu = false;
    }
}
