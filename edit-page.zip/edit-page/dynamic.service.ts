import {
    Injectable,
    ApplicationRef,
    ComponentFactoryResolver,
    Injector,
    EmbeddedViewRef, Inject,
} from '@angular/core';

import { ComPoolService } from '@/services/com-pool.service';
import {s4} from '@/tools';
import {IDynamicRes, IObj, nameForSelect} from '@views/edit-page/interface/box';
import {DOCUMENT} from '@angular/common';

const SELECTORDATA: { [prop: string]: any } = {
    contentMenu: 'app-right-menu',
    loadCom: 'app-z-lodding',
    dynamicForm: 'app-dynamic-from',
};

@Injectable({
    providedIn: 'root'
})
export class DynamicService {

    dynamicData: IDynamicRes[] = [];

    constructor(
        private applicationRef: ApplicationRef,
        private componentFactoryResolver: ComponentFactoryResolver,
        private injector: Injector,
        @Inject(DOCUMENT) private doc: Document) { }

    open(name: nameForSelect, metaData: IObj<any>): string {
        let { ele, destroy, type, dyId } = this.loadComponent(name, metaData);
        this.doc.body.appendChild(ele);
        let obj: any = {
            dyId,
            destroy: destroy,
            type
        }
        switch (name) {
            case 'contentMenu':
                Object.assign(obj, { active: true })
                break;
            case 'loadCom':
                break
            default:
        }
        this.dynamicData.push(obj);
        return dyId
    }

    close(dyId: string): void {
        let ind = this.dynamicData.findIndex(it => it.dyId == dyId);
        if (ind != -1) {
            this.dynamicData[ind].destroy();
            this.dynamicData.splice(ind, 1);
        }
    }

    closeLast(): void {
        this.dynamicData.shift()?.destroy();
    }

    closeAll() {
        this.dynamicData.forEach(it => it.destroy());
        this.dynamicData = [];
    }

    closeByType(type: string) {
        let resArr = this.dynamicData.filter(it => it.type == type);
        resArr.forEach(it => {
            it.destroy();
            let ind = this.dynamicData.findIndex(i => i === it);
            this.dynamicData.splice(ind, 1);
        })
    }

    loadComponent(name: nameForSelect, metaData: IObj<any>): IDynamicRes {
        let dyId = this.setProId();
        Object.assign(metaData, { dyId })
        let selector = SELECTORDATA[name];
        let target = ComPoolService.getCom(selector);
        let compFac = this.componentFactoryResolver.resolveComponentFactory(target);
        let propArr = ComPoolService.getProp(selector);
        let compRef = compFac.create(this.injector);
        propArr.forEach(item => {
            if(item.key in metaData)
                compRef.instance[item.key] = metaData[item.key];
        })
        this.applicationRef.attachView(compRef.hostView);
        return {
            ele: (compRef.hostView as EmbeddedViewRef<any>).rootNodes[0],
            destroy: (callback?: Function) => {
                callback && callback();
                this.applicationRef.detachView(compRef.hostView);
                compRef.destroy();
            },
            type: name,
            dyId
        }
    }

    isHave(dyId: string): Boolean {
        return !!this.dynamicData.find(it => it.dyId == dyId)
    }

    isActive(dyId: string): Boolean {
        return !!this.dynamicData.find(it => it.dyId == dyId)?.active
    }

    setActive(dyId: string, status: Boolean) {
        let obj = this.dynamicData.find(it => it.dyId == dyId);
        if (obj) obj.active = status;
    }

    setProId(): string {
        return `${s4()}${s4()}-${s4()}-${s4()}-${s4()}-${s4()}${s4()}${s4()}`
    }
}
