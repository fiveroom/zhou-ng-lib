import {Component, OnInit, Input, ElementRef, AfterViewInit, HostListener, HostBinding, OnDestroy, Inject} from '@angular/core';
import { trigger, transition, animate, style } from '@angular/animations';

import { IRightMenu, ISizeEle } from '../interface/box';

import { AddPara } from '../../../decorator/com-tool.decorator';

import { DynamicService } from '../dynamic.service';
import {DOCUMENT} from '@angular/common';


@Component({
    selector: 'app-right-menu',
    templateUrl: './right-menu.component.html',
    styleUrls: ['./right-menu.component.less'],
    animations: [
        trigger('insertMenu', [
            transition(':enter', [
                style({ opacity: 0, transform: 'scale(0.5)' }),
                animate('90ms', style({ opacity: 1, transform: 'scale(1)' }))
            ]),
            transition(':leave', [
                animate('90ms', style({ opacity: 0, transform: 'scale(0.5)' }))
            ])
        ])
    ]
})
export class RightMenuComponent implements OnInit, AfterViewInit, OnDestroy {
    @HostBinding('@insertMenu')


    @Input() @AddPara() menuArr: Array<IRightMenu> = [];
    @Input() @AddPara() clickLocat: ISizeEle;
    @Input() @AddPara() childLoact: ISizeEle;
    @Input() @AddPara() children: IRightMenu[] = [];
    @Input() @AddPara() dyId: string = '';

    showChildTimer: any;
    closeChildTimer: any;
    hostLeaveTimer: any;

    shadow: any;
    top: number;
    left: number;

    constructor(
        private hostView: ElementRef,
        private dysc: DynamicService,
                @Inject(DOCUMENT) private doc: Document
    ) {
    }

    get hostSize(): { width: number; height: number } {
        let ele = this.hostView.nativeElement as HTMLElement;
        return { width: ele?.offsetWidth, height: ele?.offsetHeight }
    }

    get menuArrShow(): Array<IRightMenu> {
        return this.menuArr?.filter((it: IRightMenu) => {
            if ('show' in it) {
                return it.show
            }
            return true
        })
    }

    @HostListener('mouseenter')
    hosetEnter() {
        if (this.childLoact) {
            this.dysc.setActive(this.dyId, true);
        }
    }

    @HostListener('mouseleave')
    hosetLeave() {
        if (this.childLoact) {
            if (this.dysc.isHave(this.dyId)) {
                this.dysc.setActive(this.dyId, false);
                clearTimeout(this.hostLeaveTimer);
                this.hostLeaveTimer = setTimeout(() => {
                    if (!this.dysc.isActive(this.dyId))
                        this.dysc.close(this.dyId);
                }, 0);
            }
        }
    }

    @HostListener('click', ['$event'])
    hoseClick(evt: MouseEvent) {
        evt.stopPropagation()
    }

    ngOnInit(): void {

    }

    ngOnDestroy() {
        if (this.clickLocat &&  this.shadow){
            this.shadow.style.display = 'none';
        }
    }

    ngAfterViewInit() {
        if (this.childLoact) {
            this.computerChildMenu();
        } else {
            this.computerMenu();
            this.insertShadow();
        }
    }

    computerMenu() {
        let { width, height } = this.hostSize;
        let { offsetWidth: pageW, offsetHeight: pageH } = this.doc.body;
        let rDis = pageW - this.clickLocat.left;
        let bDis = pageH - this.clickLocat.top;
        let top = this.clickLocat.top;
        let left = this.clickLocat.left;
        if (this.clickLocat.top - height >= 0 && bDis - height < 0) {
            top = this.clickLocat.top - height;
        }
        if (this.clickLocat.left - width >= 0 && rDis - width < 0) {
            left = this.clickLocat.left - width;
        }
        this.hostView.nativeElement.style.top = top + 'px';
        this.hostView.nativeElement.style.left = left + 'px';
    }

    computerChildMenu() {
        let { left, top, bottom, right } = this.childLoact;
        let {
            width: widthBox,
            height: heightBox,
        } = this.hostSize;
        let { offsetWidth: pageW, offsetHeight: pageH } = this.doc.body;
        let needT = top;
        let needL = right - 4;
        if (needL + widthBox > pageW) {
            needL = left - widthBox + 4;
        }
        if (needT + heightBox > pageH) {
            needT = bottom - heightBox;
        }
        this.hostView.nativeElement.style.top = needT + 'px';
        this.hostView.nativeElement.style.left = needL + 'px';
    }

    clickEvent(evt: MouseEvent, item: IRightMenu, ind: number) {
        evt.stopPropagation()
        if (typeof (item.method) == 'function')
            item.method({ evt, item, ind });
        switch (item.clsType ?? 'all') {
            case 'no':
                break;
            case 'self':
                this.dysc.close(this.dyId);
                break;
            default:
                this.dysc.closeAll();
                break;
        }
    }

    mouseEnter(evt: MouseEvent, menuObj: IRightMenu): void {
        if (menuObj.children?.length) {
            if (this.dysc.isHave(menuObj.childId)) {
                this.dysc.setActive(menuObj.childId, true);
                return;
            } else {
                clearTimeout(this.showChildTimer);
                this.showChildTimer = setTimeout(() => {
                    let size = (evt.target as any).getBoundingClientRect();
                    menuObj.childId = this.dysc.open(
                        'contentMenu',
                        {
                            menuArr: menuObj.children,
                            childLoact: {
                                left: size.left,
                                top: size.top - 6,
                                bottom: size.bottom - 6,
                                right: size.right
                            }
                        });
                }, 0);
            }
        }
    }

    mouseleave(menuObj: IRightMenu): void {
        if (menuObj.children?.length) {
            this.dysc.setActive(menuObj.childId, false);
            clearTimeout(this.showChildTimer);
            clearTimeout(this.closeChildTimer);
            this.closeChildTimer = setTimeout(() => {
                if (this.dysc.isHave(menuObj.childId)) {
                    if (!this.dysc.isActive(menuObj.childId)) {
                        this.dysc.close(menuObj.childId);
                    }
                }
            }, 0);
        }
    }

    insertShadow() {
        this.shadow = this.doc.getElementById('rightShadow');
        if (!this.shadow) {
            this.shadow = this.doc.createElement('div') ;
            (this.shadow as Element).setAttribute('id', 'rightShadow')
            this.shadow.classList.add('shadow');
            this.shadow.onclick = () => {
                this.dysc.closeByType('contentMenu')
            }
            this.doc.body.appendChild(this.shadow);
        }
        this.shadow.style.display ='block';
    }

    stopEvent(event: MouseEvent) {
        // event.stopPropagation()
    }



}
